﻿using FrooxEngine;
using FrooxEngine.Store;
using System;
using System.IO;
using System.Threading.Tasks;

namespace MTLXImporter;

public static class ImageHelper
{
    public static async Task<StaticTexture2D> ImportImage(string path, World world)
    {
        await default(ToBackground);
        Uri uri = new(path);
        if (!uri.IsWellFormedOriginalString())
        {
            var localDB = world.Engine.LocalDB;
            uri = await localDB.ImportLocalAssetAsync(path, LocalDB.ImportLocation.Copy).ConfigureAwait(continueOnCapturedContext: false);
        }

        await default(ToWorld);
        StaticTexture2D comp = null;
        foreach (var c in world.AssetsSlot.GetComponentsInChildren<StaticTexture2D>())
        {
            if (c is StaticTexture2D staticTexture)
            {
                if (staticTexture.URL.Value == uri)
                    return staticTexture;
            }
        }

        var textureSlot = world.AssetsSlot.FindChild((s) => s.Name == "mtlxImporter");
        if (comp == null)
        {
            textureSlot ??= world.AssetsSlot.AddSlot("mtlxImporter");
        }

        textureSlot.Name = Path.GetFileNameWithoutExtension(path);
        StaticTexture2D tex = textureSlot.AttachComponent<StaticTexture2D>();
        tex.URL.Value = uri;
        return tex;
    }
}
