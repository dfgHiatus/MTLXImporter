﻿using Elements.Assets;
using Elements.Core;
using FrooxEngine;
using HarmonyLib;
using ResoniteModLoader;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace MTLXImporter
{
    public class MTLXImporter : ResoniteMod
    {
        public override string Name => "MTLXImporter";
        public override string Author => "dfgHiatus";
        public override string Version => "1.0.0";
        public override string Link => "https://github.com/dfgHiatus/MTLXImporter/";

        [AutoRegisterConfigKey]
        public static readonly ModConfigurationKey<bool> enabled =
            new("enabled", "Enabled", () => true);

        internal static ModConfiguration config;
        internal static readonly HashSet<string> USD_FILE_EXTENSIONS = new() { ".usd", ".usdc" };
        internal static readonly HashSet<string> MTLX_FILE_EXTENSIONS = new() { ".mtlx" };

        public override void OnEngineInit()
        {
            new Harmony("net.dfgHiatus.MTLXImporter").PatchAll();
            config = GetConfiguration();
            Engine.Current.RunPostInit(() => AssetPatch());
        }

        private static void AssetPatch()
        {
            var aExt = Traverse.
                Create(typeof(AssetHelper)).
                Field<Dictionary<AssetClass, List<string>>>("associatedExtensions");
            foreach (var ext in MTLX_FILE_EXTENSIONS)
                aExt.Value[AssetClass.Special].Add(ext);
        }

        [HarmonyPatch(typeof(UniversalImporter), 
            "ImportTask", 
            typeof(AssetClass), 
            typeof(IEnumerable<string>), 
            typeof(World), 
            typeof(float3), 
            typeof(floatQ), 
            typeof(float3), 
            typeof(bool))]
        public class UniversalImporterPatch
        {
            public static bool Prefix(IEnumerable<string> files, ref Task __result)
            {
                Debug("UniversalImporterPatch Prefix start"); // Use Debug for print debugging
                List<string> query = new();
                foreach (var file in files)
                {
                    Debug($"Processing file: {file}"); // Use Debug for print debugging
                    if (MTLX_FILE_EXTENSIONS.Contains(Path.GetExtension(file)))
                    {
                        query.Add(file);
                        Debug($"Added file to query: {file}"); // Use Debug for print debugging
                    }
                }

                if (query.Count() > 0)
                {
                    __result = ProcessMTLXImport(query);
                    Debug("MTLX import started"); // Use Debug for print debugging
                }

                Debug("UniversalImporterPatch Prefix end"); // Use Debug for print debugging
                return true;
            }
        }

        private static async Task ProcessMTLXImport(List<string> files)
        {
            Debug("ProcessMTLXImport start"); // Use Debug for print debugging

            for (int i = 0; i < files.Count; i++)
            {
                await default(ToBackground);
                var file = files[i];
                Debug($"Processing MTLX file {i + 1}/{files.Count}: {file}"); // Use Debug for print debugging

                // Deserialize the materialx file
                var matX = XMLHelper.Deserialize<materialx>(file);
                Debug($"MaterialX file deserialized: {file}"); // Use Debug for print debugging

                // Get the name of the material
                var name = ((materialxStandard_surface)matX.Items.First()).name;
                Debug($"Material name extracted: {name}"); // Use Debug for print debugging

                // Add a slot to the world
                await default(ToWorld);
                var slot = Engine.Current.WorldManager.FocusedWorld.AddSlot(name);
                slot.PositionInFrontOfUser();
                slot.GlobalPosition += new float3(i * .2f, 0f, 0f);
                Debug($"Slot added to the world: {slot}"); // Use Debug for print debugging

                // Setup textures for the material
                await default(ToBackground);
                var assetDict = await SetupTextures(file, matX, slot).ConfigureAwait(false);
                Debug($"Textures set up for the material: {file}"); // Use Debug for print debugging

                // Check for the presence of Specular texture and set up the material accordingly
                if (assetDict.ContainsKey(TextureType.Specular))
                {
                    await SetupSpecular(slot, assetDict);
                    Debug($"Specular setup completed for the material: {file}"); // Use Debug for print debugging
                }
                else
                {
                    await SetupMetallic(slot, assetDict);
                    Debug($"Metallic setup completed for the material: {file}"); // Use Debug for print debugging
                }

                Debug($"MTLX file processed: {file}"); // Use Debug for print debugging
            }

            Debug("ProcessMTLXImport end"); // Use Debug for print debugging
        }

        private static async Task<Dictionary<TextureType, StaticTexture2D>> SetupTextures(string file, materialx material, Slot slot)
        {
            Debug("SetupTextures start"); // Use Debug for print debugging

            await default(ToBackground);
            Dictionary<TextureType, StaticTexture2D> assetDict = new();

            foreach (var unknownTexture in material.Items)
            {
                switch (unknownTexture)
                {
                    case materialxNormalmap:
                        var mNM = unknownTexture as materialxNormalmap;
                        var path1 = Path.Combine(Path.GetDirectoryName(file), mNM.name);
                        Debug($"Processing Normalmap: {path1}"); // Use Debug for print debugging
                        var img1 = await ImageHelper.ImportImage(path1, slot.World);
                        assetDict.Add(TextureType.Normal, img1);
                        Debug($"Normalmap processed and added to assetDict"); // Use Debug for print debugging
                        break;
                    case materialxDisplacement:
                        var mD = unknownTexture as materialxDisplacement;
                        var path2 = Path.Combine(Path.GetDirectoryName(file), mD.name);
                        Debug($"Processing Displacement: {path2}"); // Use Debug for print debugging
                        var img2 = await ImageHelper.ImportImage(path2, slot.World);
                        assetDict.Add(TextureType.Height, img2);
                        Debug($"Displacement processed and added to assetDict"); // Use Debug for print debugging
                        break;
                    case materialxTiledimage:
                        var mTi = unknownTexture as materialxTiledimage;
                        var determination = DetermineTiledImageType(mTi);
                        var path3 = Path.Combine(Path.GetDirectoryName(file), determination.text);
                        Debug($"Processing Tiledimage: {path3}"); // Use Debug for print debugging
                        var img3 = await ImageHelper.ImportImage(path3, slot.World);
                        assetDict.Add(determination.textureType, img3);
                        Debug($"Tiledimage processed and added to assetDict"); // Use Debug for print debugging
                        break;
                    default:
                        break;
                }
            }

            Debug("SetupTextures end"); // Use Debug for print debugging
            return assetDict;
        }

        private static DataTransferObject DetermineTiledImageType(materialxTiledimage mTi)
        {
            Debug("DetermineTiledImageType start"); // Use Debug for print debugging

            var loweredName = mTi.name.ToLower();
            var dto = new DataTransferObject
            {
                text = mTi.input.First().value
            };

            if (loweredName.Contains("color"))
            {
                dto.textureType = TextureType.Albedo;
                Debug($"Tiledimage type determined: Albedo"); // Use Debug for print debugging
            }
            else if (loweredName.Contains("roughness"))
            {
                dto.textureType = TextureType.Roughness;
                Debug($"Tiledimage type determined: Roughness"); // Use Debug for print debugging
            }
            else if (loweredName.Contains("normal"))
            {
                dto.textureType = TextureType.Normal;
                Debug($"Tiledimage type determined: Normal"); // Use Debug for print debugging
            }
            else if (loweredName.Contains("displacement"))
            {
                dto.textureType = TextureType.Height;
                Debug($"Tiledimage type determined: Height"); // Use Debug for print debugging
            }
            else
            {
                dto.textureType = TextureType.UNKNOWN;
                Debug($"Tiledimage type determined: UNKNOWN"); // Use Debug for print debugging
            }

            Debug("DetermineTiledImageType end"); // Use Debug for print debugging
            return dto;
        }

        private static async Task SetupMetallic(Slot slot, Dictionary<TextureType, StaticTexture2D> assetDict)
        {
            Debug("SetupMetallic start"); // Use Debug for print debugging
            await default(ToWorld);
            var resoniteMat = slot.CreateMaterialOrb<PBS_Metallic>();

            foreach (var texture in assetDict)
            {
                var type = texture.Key;
                assetDict.TryGetValue(type, out var tex);

                switch (type)
                {
                    case TextureType.Albedo:
                        resoniteMat.AlbedoTexture.Target = tex;
                        Debug($"Albedo texture set for Metallic material"); // Use Debug for print debugging
                        break;
                    case TextureType.Normal:
                        tex.IsNormalMap.Value = true;
                        resoniteMat.NormalMap.Target = tex;
                        Debug($"Normal texture set for Metallic material"); // Use Debug for print debugging
                        break;
                    case TextureType.Height:
                        resoniteMat.HeightMap.Target = tex;
                        Debug($"Height texture set for Metallic material"); // Use Debug for print debugging
                        break;
                    case TextureType.Emissive:
                        resoniteMat.EmissiveMap.Target = tex;
                        Debug($"Emissive texture set for Metallic material"); // Use Debug for print debugging
                        break;
                    case TextureType.Roughness:
                        resoniteMat.MetallicMap.Target = tex;
                        Debug($"Roughness texture set for Metallic material"); // Use Debug for print debugging
                        break;
                    case TextureType.AmbientOcclusion:
                        resoniteMat.OcclusionMap.Target = tex;
                        Debug($"Ambient Occlusion texture set for Metallic material"); // Use Debug for print debugging
                        break;
                    case TextureType.Specular:
                    case TextureType.UNKNOWN:
                    default:
                        break;
                }
            }

            Debug("SetupMetallic end"); // Use Debug for print debugging
        }

        private static async Task SetupSpecular(Slot slot, Dictionary<TextureType, StaticTexture2D> assetDict)
        {
            Debug("SetupSpecular start"); // Use Debug for print debugging
            await default(ToWorld);
            var resoniteMat = slot.CreateMaterialOrb<PBS_Specular>();

            foreach (var texture in assetDict)
            {
                var type = texture.Key;
                assetDict.TryGetValue(type, out var tex);

                switch (type)
                {
                    case TextureType.Albedo:
                        resoniteMat.AlbedoTexture.Target = tex;
                        Debug($"Albedo texture set for Specular material"); // Use Debug for print debugging
                        break;
                    case TextureType.Normal:
                        tex.IsNormalMap.Value = true;
                        resoniteMat.NormalMap.Target = tex;
                        Debug($"Normal texture set for Specular material"); // Use Debug for print debugging
                        break;
                    case TextureType.Height:
                        resoniteMat.HeightMap.Target = tex;
                        Debug($"Height texture set for Specular material"); // Use Debug for print debugging
                        break;
                    case TextureType.Emissive:
                        resoniteMat.EmissiveMap.Target = tex;
                        Debug($"Emissive texture set for Specular material"); // Use Debug for print debugging
                        break;
                    case TextureType.Specular:
                        resoniteMat.SpecularMap.Target = tex;
                        Debug($"Specular texture set for Specular material"); // Use Debug for print debugging
                        break;
                    case TextureType.AmbientOcclusion:
                        resoniteMat.OcclusionMap.Target = tex;
                        Debug($"Ambient Occlusion texture set for Specular material"); // Use Debug for print debugging
                        break;
                    case TextureType.Roughness:
                    case TextureType.UNKNOWN:
                    default:
                        break;
                }
            }

            Debug("SetupSpecular end"); // Use Debug for print debugging
        }

        public class DataTransferObject
        {
            public string text;
            public TextureType textureType;

            public DataTransferObject()
            {
                text = string.Empty;
                textureType = TextureType.UNKNOWN;
            }
        }
    }
}
